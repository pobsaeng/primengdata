export interface Employee {
    name?;
    empId?;
    city?;
}